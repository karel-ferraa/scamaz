extends Node2D

var peer = ENetMultiplayerPeer.new()
@onready var ip_text  = $IP
@onready var ip_input = $IPrentre
@onready var texte    = $Label2

func get_local_ip():
	var adresse_ip = IP.get_local_addresses()
	for ip in adresse_ip:
		if not ":" in ip and not ip.begins_with("127."):
			if ip.begins_with("192.168.") or ip.begins_with("10.") or ip.begins_with("172."):
				return ip
	return "IP pas trouvée"

func _on_button_host_pressed():
	ip_text.text    = "Ton IP : " + get_local_ip()
	ip_text.visible = true
	texte.visible   = false
	peer.create_server(9999, 2)
	multiplayer.multiplayer_peer = peer
	multiplayer.peer_connected.connect(_on_peer_connected)

func _on_peer_connected(_id):
	rpc("_lancer_jeu")
	call_deferred("_changer_scene")

@rpc("authority", "call_remote", "reliable")
func _lancer_jeu():
	call_deferred("_changer_scene")

func _changer_scene():
	get_tree().change_scene_to_file("res://Scènes/niv.tscn")

func _on_button_client_pressed():
	var ip_saisie = ip_input.text.strip_edges()
	if ip_saisie.is_empty():
		print("Erreur : Pas d'IP")
		return
	peer.create_client(ip_saisie, 9999)
	multiplayer.multiplayer_peer = peer
