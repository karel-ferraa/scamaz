extends Node2D

var peer = ENetMultiplayerPeer.new()
@export var player_scene:PackedScene
@onready var ip_text = $IP
@onready var ip_input = $IPrentre
@onready var texte = $Label2

func get_local_ip():
	var adresse_ip = IP.get_local_addresses()
	var ipv4 = "IP pas trouvée"
	for ip in adresse_ip:
		if not ":" in ip and not ip.begins_with("127."):
			if ip.begins_with("192.168.") or ip.begins_with("10.") or ip.begins_with("172."):
				ipv4 = ip
				return ipv4
			if ipv4 == "IP non trouvée":
				ipv4 = ip
	return ipv4

func _on_button_host_pressed():
	var mon_ip = get_local_ip()
	ip_text.text = "Ton IP est " + mon_ip
	texte.visible = false
	ip_text.visible = true
	await get_tree().create_timer(10.0).timeout
	ip_text.visible = false
	peer.create_server(9999, 2)
	multiplayer.multiplayer_peer = peer
	multiplayer.peer_connected.connect(_add_player)
	_add_player()

func _add_player(id = 1):
	var player = player_scene.instantiate()
	player.name = str(id)
	call_deferred("add_child",player)

func _on_button_client_pressed():
	var ip_saisie = ip_input.text
	ip_saisie = ip_saisie.strip_edges()
	if ip_saisie.is_empty():
		print("Erreur : Pas d'IP")
		return
	peer.create_client(ip_saisie, 9999)
	multiplayer.multiplayer_peer = peer
