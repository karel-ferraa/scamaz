extends Node2D

var peer = ENetMultiplayerPeer.new()
@onready var ip_text  = $IP
@onready var ip_input = $IPrentre
@onready var texte    = $Label2
@onready var ami      = $ami
@onready var hosty    = $Button_Host
@onready var joiny    = $Button_Client

func get_local_ip():
	var adresse_ip = IP.get_local_addresses()
	for ip in adresse_ip:
		if not ":" in ip and not ip.begins_with("127."):
			if ip.begins_with("192.168.") or ip.begins_with("10.") or ip.begins_with("172."):
				return ip
	return "IP pas trouvée"

func _cacher_ui():
	texte.visible    = false
	ami.visible      = false
	ip_input.visible = false
	hosty.visible    = false
	joiny.visible    = false
	ip_text.visible  = false

# ─── HOST ────────────────────────────────────────────
func _on_button_host_pressed():
	ip_text.text    = "Ton IP : " + get_local_ip()
	ip_text.visible = true
	texte.visible   = false
	peer.create_server(9999, 2)
	multiplayer.multiplayer_peer = peer
	# Quand le client se connecte → lancer le jeu sur les 2
	multiplayer.peer_connected.connect(_on_peer_connected)

func _on_peer_connected(_id):
	_cacher_ui()
	# Dire au CLIENT de changer de scène
	rpc("_lancer_jeu")
	# Changer de scène aussi sur le SERVEUR
	get_tree().change_scene_to_file("res://Scènes/niv.tscn")

# ─── CLIENT ──────────────────────────────────────────
func _on_button_client_pressed():
	var ip_saisie = ip_input.text.strip_edges()
	if ip_saisie.is_empty():
		print("Erreur : Pas d'IP")
		return
	_cacher_ui()
	peer.create_client(ip_saisie, 9999)
	multiplayer.multiplayer_peer = peer

# ─── CHANGEMENT DE SCÈNE ─────────────────────────────
@rpc("authority", "call_remote", "reliable")
func _lancer_jeu():
	get_tree().change_scene_to_file("res://Scènes/niv.tscn")
